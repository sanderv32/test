SDK Development Guide @ https://espressif.com/sites/default/files/documentation/2a-esp8266-sdk_getting_started_guide_en.pdf
All documentations @ https://espressif.com/en/support/download/documents?keys=&field_type_tid%5B%5D=14
